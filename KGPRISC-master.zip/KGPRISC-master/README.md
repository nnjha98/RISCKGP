# KGPRISC

It is a Single Cycle CPU design (RISC architecture) developed in Xilinx ISE 14.7 using Verilog.

The `KGPRISC.pdf` file is a User Guide for KGPRISC, where the architecture design, ISA, instruction encoding and instruction format is written.

To run it on any PC, download Xilinx ISE 14.7, and create a project. Add source files to the project and run using the testbench.
